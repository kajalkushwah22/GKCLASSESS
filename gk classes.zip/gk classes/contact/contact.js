// Add interactivity for future enhancements if needed
document.addEventListener('DOMContentLoaded', () => {
    console.log('Contact section loaded successfully!');
  });
  